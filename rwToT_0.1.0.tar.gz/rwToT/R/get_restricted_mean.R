#' @export
get_restricted_mean <-  function(cohort, t){

  ## Parameters
  mean.predicted = NULL
  mean.u95 = NULL
  mean.l95 = NULL
  mean.sum = NULL
  best.model.mean = NULL
  output.model = NULL

  rw.cohort <- cohort
  disp.cnt <- table(rw.cohort$CNSR)
  disp.prop <- round((table(rw.cohort$CNSR)/sum(table(rw.cohort$CNSR)))*100, 1)
  disp.no  <-  paste(disp.cnt, " (", disp.prop, "%)", sep="")

  ### Perform pocock method. If pocock method not suitable, move on to parametric method
  rw.cohort$SurvObj <- with(rw.cohort, survival::Surv(DD, CNSR == 0))
  km.cohort <- survival::survfit(SurvObj ~ 1, data = rw.cohort, conf.type = "log-log")

  output_km_curve <-  data.frame(cbind(time = km.cohort$time,
                                     nRisk = km.cohort$n.risk,
                                     nEvent = km.cohort$n.event,
                                     nCensor = km.cohort$n.censor,
                                     pSurv = km.cohort$surv,
                                     upper = km.cohort$upper,
                                     lower = km.cohort$lower))


  nRisk_original <-  output_km_curve[1,'nRisk']*0.1
  tmp_km_curve <- output_km_curve %>% dplyr::filter(time <= t) %>% dplyr::arrange(desc(time))
  nRisk_t <-  tmp_km_curve[1,'nRisk']

  if (nRisk_t >= nRisk_original) {
    res <- survival:::survmean(km.cohort, rmean = t)

    rmean.ci <- paste(round(12*res$matrix[5]/365, 1), " (",
                      round(12*(res$matrix[5] - 1.96*res$matrix[6])/365, 1),
                      " - ", round(12*(res$matrix[5] + 1.96*res$matrix[6])/365, 1), ")", sep = "")

    return(list("mean"=rmean.ci, "parametric_km"=NULL))
  }
  else {
    pembro.rwdtot <- rw.cohort
    pembro.rwdtot$SurvObj <- with(pembro.rwdtot, survival::Surv(DD, CNSR == 0))
    res.weibull <- tryCatch(flexsurv::flexsurvreg(SurvObj ~ 1, data=pembro.rwdtot, dist="weibull"), error = function(e) NA)
    res.exp <- tryCatch(flexsurv::flexsurvreg(SurvObj ~ 1, data=pembro.rwdtot, dist="exponential"), error = function(e) NA)
    res.lognorm <- tryCatch(flexsurv::flexsurvreg(SurvObj ~ 1, data=pembro.rwdtot, dist="lnorm"), error = function(e) NA)
    res.loglogist <- tryCatch(flexsurv::flexsurvreg(SurvObj ~ 1, data=pembro.rwdtot, dist="llogis"), error = function(e) NA)
    res.gomp <- tryCatch(flexsurv::flexsurvreg(SurvObj ~ 1, data=pembro.rwdtot, dist="gompertz"), error = function(e) NA)

    # AIC = -2*loglik + 2p
    # BIC = -2*loglik + log(n)*p
    model.type <-  c("Exp", "Weibull", "LogNorm", "LogLogist", "Gompertz")
    res.exp$AIC <- tryCatch(res.exp$AIC, error = function(e) NA)
    res.weibull$AIC <- tryCatch(res.weibull$AIC, error = function(e) NA)
    res.lognorm$AIC <- tryCatch(res.lognorm$AIC, error = function(e) NA)
    res.loglogist$AIC <- tryCatch(res.loglogist$AIC, error = function(e) NA)
    res.gomp$AIC <- tryCatch(res.gomp$AIC, error = function(e) NA)
    model.aic <- c(res.exp$AIC, res.weibull$AIC,
                   res.lognorm$AIC, res.loglogist$AIC,
                   res.gomp$AIC)
    model.sum <- as.data.frame(cbind(model.type, model.aic), stringsAsFactors = FALSE)
    names(model.sum) <- c("type", "AIC")

    best.model <- model.sum[as.numeric(model.sum$AIC) == min(as.numeric(model.sum$AIC), na.rm = TRUE), "type"][1]
    if (best.model == "Exp"){
      output.model = res.exp
      mean.predicted <- round(flexsurv::rmst_exp(t, rate = res.exp$res[1, 1], start = 0)*12/365, 1)
      mean.u95 <- round(flexsurv::rmst_exp(t, rate = res.exp$res[1, 2], start = 0)*12/365, 1)
      mean.l95 <- round(flexsurv::rmst_exp(t, rate = res.exp$res[1, 3], start = 0)*12/365, 1)
      mean.sum <- paste(mean.predicted, " (", mean.l95, " - ", mean.u95, ")", sep = "")
      best.model.mean <- list(mean.sum, "Exp")
      } else if (best.model == "Weibull") {
      output.model = res.weibull
      mean.predicted <- round(flexsurv::rmst_weibull(t, shape = res.weibull$res[1, 1], scale = res.weibull$res[2, 1], start = 0)*12/365, 1)
      mean.l95 <- round(flexsurv::rmst_weibull(t, shape = res.weibull$res[1, 2], scale = res.weibull$res[2, 2], start = 0)*12/365, 1)
      mean.u95 <- round(flexsurv::rmst_weibull(t, shape = res.weibull$res[1, 3], scale = res.weibull$res[2, 3], start = 0)*12/365, 1)
      mean.sum <- paste(mean.predicted, " (", mean.l95, " - ", mean.u95, ")", sep = "")
      best.model.mean <- list(mean.sum, "Weibull")
    } else if (best.model == "LogNorm") {
      output.model = res.lognorm
      mean.predicted <- round(flexsurv::rmst_lnorm(t, meanlog = res.lognorm$res[1, 1], sdlog = res.lognorm$res[2, 1], start = 0)*12/365, 1)
      mean.l95 <- round(flexsurv::rmst_lnorm(t, meanlog = res.lognorm$res[1, 2], sdlog = res.lognorm$res[2, 2], start = 0)*12/365, 1)
      mean.u95 <- round(flexsurv::rmst_lnorm(t, meanlog = res.lognorm$res[1, 3], sdlog = res.lognorm$res[2, 3], start = 0)*12/365, 1)
      mean.sum <- paste(mean.predicted, " (", mean.l95, " - ", mean.u95, ")", sep = "")
      best.model.mean <- list(mean.sum, "LogNorm")
    } else if (best.model == "LogLogist") {
      output.model = res.loglogist
      mean.predicted <- round(flexsurv::rmst_llogis(t, shape = res.loglogist$res[1, 1], scale = res.loglogist$res[2, 1], start = 0)*12/365, 1)
      mean.l95 <- round(flexsurv::rmst_llogis(t, shape = res.loglogist$res[1, 2], scale = res.loglogist$res[2, 2], start = 0)*12/365, 1)
      mean.u95 <- round(flexsurv::rmst_llogis(t, shape = res.loglogist$res[1, 3], scale = res.loglogist$res[2, 3], start = 0)*12/365, 1)
      mean.sum <- paste(mean.predicted, " (", mean.l95, " - ", mean.u95, ")", sep = "")
      best.model.mean <- list(mean.sum, "LogLogist")
    } else if (best.model == "Gompertz") {
      output.model = res.gomp
      mean.predicted <- round(flexsurv::rmst_gompertz(t, shape = res.gomp$res[1, 1], rate = res.gomp$res[2, 1], start = 0)*12/365, 1)
      mean.u95 <- round(flexsurv::rmst_gompertz(t, shape = res.gomp$res[1, 2], rate = res.gomp$res[2, 2], start = 0)*12/365, 1)
      mean.l95<- round(flexsurv::rmst_gompertz(t, shape = res.gomp$res[1, 3], rate = res.gomp$res[2, 3], start = 0)*12/365, 1)
      mean.sum <- paste(mean.predicted, " (", mean.l95, " - ", mean.u95, ")", sep = "")
      best.model.mean <- list(mean.sum, "Gompertz")
    }

    # Uncomment this if you want the raw pocock curve data
    #write.csv(output_km_curve, file="HNSCC_2L pembro mono_output_km_curve.csv", row.names=FALSE)


    # Uncomment this if you want the raw parametric curve data
    d = 0:1460
    output_extra_km_curve = summary(output.model, t=d)[[1]]
    #write.csv(output_extra_km_curve, file="HNSCC_progressed_output_extra_km_curve.csv", row.names=FALSE)

    names(best.model.mean) <- c("mean", "model")
    output = paste(best.model.mean$mean, " [", best.model.mean$model, "]", sep = "")
    return(list("mean"=output, "parametric_km"=output_extra_km_curve))

  }
}
