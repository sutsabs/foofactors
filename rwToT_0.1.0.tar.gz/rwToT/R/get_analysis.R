#' @export
get_analysis <-  function(cohort, cohort_type, database_cutoff_date, trial_type="non-trial"){
  #parameters
  cohort$SurvObj <- with(cohort, survival::Surv(DD, CNSR == 0))
  cohort_km <- survival::survfit(SurvObj ~ 1, data = cohort, conf.type = "log-log")
  cohort_summary <- as.data.frame(cbind(cohort_km$time, cohort_km$surv, cohort_km$upper, cohort_km$lower))
  names(cohort_summary) <- c("time", "prob", "95ucl", "95lcl")

  ## Get the total number of patients
  output_npatients = length(cohort$DD)

  ## Get Discontinued and Censored data
  table_censor_counts = table(cohort$CNSR)
  table_censor_proportions = round(100*table_censor_counts/sum(table_censor_counts), 1)
  calc_censor = paste(table_censor_counts, " (", table_censor_proportions, "%)", sep="")

  output_discontinued = calc_censor[1]
  output_censored = calc_censor[2]

  if (trial_type != "trial")
  {
    ## Get Median (Range) Database Followup data
    calc_median_database_followup = round(12*median(as.Date(database_cutoff_date, format = "%Y-%m-%d") - as.Date(cohort$START_DATE, format = "%Y-%m-%d"))/365, 1)
    calc_range_database_followup = round(12*range(as.Date(database_cutoff_date, format = "%Y-%m-%d") - as.Date(cohort$START_DATE, format = "%Y-%m-%d"))/365, 1)
    if (calc_range_database_followup[1] == 0) {calc_range_database_followup[1] = "1 day"}
    output_median_database_followup = paste(calc_median_database_followup, " (", calc_range_database_followup[1], " - ", calc_range_database_followup[2],")", sep = "")

    ## Get Median (Range) Patient Followup data
    calc_median_patient_followup = round(12*median(as.Date(cohort$LAST_ACTIVITY_DATE, format = "%Y-%m-%d") - as.Date(cohort$START_DATE, format = "%Y-%m-%d"))/365, 1)
    calc_range_patient_followup = round(12*range(as.Date(cohort$LAST_ACTIVITY_DATE, format = "%Y-%m-%d") - as.Date(cohort$START_DATE, format = "%Y-%m-%d"))/365, 1)
    if (calc_range_patient_followup[1] == 0) {calc_range_patient_followup[1] = "1 day"}
    output_median_patient_followup = paste(calc_median_patient_followup, " (", calc_range_patient_followup[1], " - ", calc_range_patient_followup[2],")", sep = "")

  }
  else {
    output_median_database_followup = NA
    output_median_patient_followup = NA

    #calc_median_patient_followup = round(12*median(cohort$DD)/365, 1)
    #calc_range_patient_followup = round(12*range(cohort$DD)/365, 1)

    #output_median_patient_followup = paste(calc_median_patient_followup, " (", calc_range_patient_followup[1], " - ", calc_range_patient_followup[2],")", sep = "")
  }

  ## Get Observed Median (Range)
  calc_range_observed_median = round(12*range(cohort$DD)/365,1)
  if (calc_range_observed_median[1] == 0) {calc_range_observed_median[1] = "1 day"}
  output_observed_median = paste(round(12*median(cohort$DD)/365, 1), " (",
                                 calc_range_observed_median[1], " - ",
                                 calc_range_observed_median[2], ")", sep="")

  ## Get KM Median (Range)
  calc_km_median = survival:::survmean(cohort_km, rmean = max(cohort$DD))
  output_km_median = paste(round((calc_km_median$matrix[7]/365)*12, 1)," (", round((calc_km_median$matrix[8]/365)*12, 1), " - ", round((calc_km_median$matrix[9]/365)*12, 1), ")", sep = "")

  # Restricted Mean Outputs
  output_rmean_9mon = get_restricted_mean(cohort, 274)
  output_rmean_12mon = get_restricted_mean(cohort, 365)
  output_rmean_18mon = get_restricted_mean(cohort, 548)
  output_rmean_24mon = get_restricted_mean(cohort, 730)
  output_rmean_30mon = get_restricted_mean(cohort,913)
  output_rmean_36mon = get_restricted_mean(cohort,1095)
  output_rmean_48mon = get_restricted_mean(cohort,1460)

  rmean_9mon = output_rmean_9mon$mean
  rmean_12mon = output_rmean_12mon$mean
  rmean_18mon = output_rmean_18mon$mean
  rmean_24mon = output_rmean_24mon$mean
  rmean_30mon = output_rmean_30mon$mean
  rmean_36mon = output_rmean_36mon$mean
  rmean_48mon = output_rmean_48mon$mean

  parametric_km = output_rmean_48mon$parametric_km

  # Treatment Rate outputs
  output_incidence_6mon = get_treatment_rate(cohort_summary,183)
  output_incidence_12mon = get_treatment_rate(cohort_summary,365)
  output_incidence_18mon = get_treatment_rate(cohort_summary,548)
  output_incidence_24mon = get_treatment_rate(cohort_summary,730)
  output_incidence_30mon = get_treatment_rate(cohort_summary,913)
  output_incidence_36mon = get_treatment_rate(cohort_summary,1095)


  table_values <- as.data.frame(c(output_npatients,
                                  output_discontinued,
                                  output_censored,
                                  output_median_database_followup,
                                  output_median_patient_followup,
                                  output_observed_median,
                                  output_km_median,
                                  rmean_9mon,
                                  rmean_12mon,
                                  rmean_18mon,
                                  rmean_24mon,
                                  rmean_30mon,
                                  rmean_36mon,
                                  rmean_48mon,
                                  output_incidence_6mon,
                                  output_incidence_12mon,
                                  output_incidence_18mon,
                                  output_incidence_24mon,
                                  output_incidence_30mon,
                                  output_incidence_36mon))

  table_names <- c("No. patient",
                   "N discontinued (%)",
                   "N censored (%)",
                   "Median (range) database follow-up months",
                   "Median (range) patient follow-up, months",
                   "Observed Median rwToT (range)",
                   "KM Median rwToT (95% CI)",
                   "Restricted mean rwToT @ 9 months (95% CI)",
                   "Restricted mean rwToT @ 12 months (95% CI)",
                   "Restricted mean rwToT @ 18 months (95% CI)",
                   "Restricted mean rwToT @ 24 months (95% CI)",
                   "Restricted mean rwToT @ 30 months (95% CI)",
                   "Restricted mean rwToT @ 36 months (95% CI)",
                   "Restricted mean rwToT @ 48 months (95% CI)",
                   "6 months on treatment rate in % (95% CI)",
                   "12 months on treatment rate in % (95% CI)",
                   "18 months on treatment rate in % (95% CI)",
                   "24 months on treatment rate in % (95% CI)",
                   "30 months on treatment rate in % (95% CI)",
                   "36 months on treatment rate in % (95% CI)")

  output_table <- as.data.frame(cbind(table_names, table_values), stringsAsFactors = FALSE)
  names(output_table) <- c("Description", cohort_type)
  return(list("output_table"=output_table, "parametric_km"=parametric_km))
}
