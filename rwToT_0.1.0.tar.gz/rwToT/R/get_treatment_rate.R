#' @export
get_treatment_rate <-  function(cohort, t){

  #parameters
  filter_time <-  cohort %>% dplyr::filter(time > t)
  filter_time <-  filter_time[1,1]

  calc_incidence <-  cohort %>% dplyr::filter(time == filter_time)
  table_incidence <-  round(calc_incidence[2:4]*100, 1)

  output <-  paste(table_incidence[1]," (", table_incidence[3]," - ", table_incidence[2],"%)", sep = "") #output

  ### RETURN ####
  return(output)
}
